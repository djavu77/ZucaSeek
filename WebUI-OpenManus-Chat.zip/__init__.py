# src/routes/__init__.py

from flask import Blueprint

# Import blueprints from individual route files
from .mocap import mocap_bp
from .animation import animation_bp
from .character import character_bp
from .ai_tools import ai_tools_bp
from .pipeline import pipeline_bp

# List of all blueprints to register
all_blueprints = [
    mocap_bp,
    animation_bp,
    character_bp,
    ai_tools_bp,
    pipeline_bp
]

def register_routes(app):
    """Register all blueprints with the Flask app."""
    for bp in all_blueprints:
        # Register blueprint with /api prefix
        app.register_blueprint(bp, url_prefix="/api")
    
    print(f"Registered {len(all_blueprints)} blueprints with /api prefix.")

