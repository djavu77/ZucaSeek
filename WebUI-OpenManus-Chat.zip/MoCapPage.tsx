import { useState } from 'react';
import BarraNavegacao from '@/components/BarraNavegacao';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { PersonStanding, Play, Pause, Settings2, Video, EyeOff } from 'lucide-react'; // Adicionado EyeOff
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';

const MoCapPage = () => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [status, setStatus] = useState<'idle' | 'capturing' | 'calibrating' | 'error'>('idle');
  const [devices, setDevices] = useState([
    { id: 'sensor-01', type: 'Body Suit', status: 'connected' },
    { id: 'sensor-02', type: 'Gloves', status: 'disconnected' },
    { id: 'camera-01', type: 'Facial Cam', status: 'connected' },
  ]);

  const handleStartCapture = () => {
    // Simulação: Iniciar captura (requer backend)
    setIsCapturing(true);
    setStatus('capturing');
    toast.success('Captura de movimento iniciada (simulado).');
  };

  const handleStopCapture = () => {
    // Simulação: Parar captura (requer backend)
    setIsCapturing(false);
    setStatus('idle');
    toast.info('Captura de movimento parada (simulado).');
  };

  const handleCalibrate = () => {
    // Simulação: Iniciar calibração (requer backend)
    const prevStatus = status;
    setStatus('calibrating');
    toast.info('Iniciando calibração (simulado)...');
    setTimeout(() => {
      setStatus(prevStatus === 'capturing' ? 'capturing' : 'idle');
      toast.success('Calibração concluída (simulado).');
    }, 2500);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Toaster position="top-center" />
      <BarraNavegacao />
      <main className="flex-1 container py-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <PersonStanding className="h-8 w-8 text-primary" />
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-50">
              Captura de Movimento
            </h1>
          </div>
          <div className="flex items-center gap-2">
            <Button variant="outline" onClick={handleCalibrate} disabled={status === 'calibrating'}>
              <Settings2 className="mr-2 h-4 w-4" />
              Calibrar
            </Button>
            {isCapturing ? (
              <Button variant="destructive" onClick={handleStopCapture} disabled={status === 'calibrating'}>
                <Pause className="mr-2 h-4 w-4" />
                Parar Captura
              </Button>
            ) : (
              <Button onClick={handleStartCapture} disabled={status === 'calibrating'}>
                <Play className="mr-2 h-4 w-4" />
                Iniciar Captura
              </Button>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Coluna Principal: Visualização */}
          <div className="lg:col-span-2">
            <Card className="h-[60vh] lg:h-[calc(100vh-18rem)] flex flex-col">
              <CardHeader>
                <CardTitle>Visualização em Tempo Real</CardTitle>
                <CardDescription>Visualização 3D do avatar e dados de captura.</CardDescription>
              </CardHeader>
              {/* Placeholder Explícito */}
              <CardContent className="flex-1 flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-b-lg border-dashed border-2 border-gray-300 dark:border-gray-700">
                <div className="text-center text-muted-foreground p-4">
                  <EyeOff className="mx-auto h-12 w-12 mb-3 text-gray-400 dark:text-gray-600" />
                  <p className="font-semibold">Espaço Reservado para Visualização 3D</p>
                  <p className="text-sm">A renderização real da captura não está implementada nesta versão simulada.</p>
                  {status === 'capturing' && <p className="mt-2 text-green-500">Status: Capturando (simulado)...</p>}
                  {status === 'calibrating' && <p className="mt-2 text-blue-500">Status: Calibrando (simulado)...</p>}
                  {status === 'idle' && <p className="mt-2 text-gray-500">Status: Inativo</p>}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Coluna Lateral: Controles e Status */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Status da Captura</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Estado:</span>
                  <Badge variant={status === 'capturing' ? 'default' : status === 'calibrating' ? 'outline' : status === 'error' ? 'destructive' : 'secondary'}>
                    {status === 'capturing' ? 'Capturando' : status === 'calibrating' ? 'Calibrando' : status === 'error' ? 'Erro' : 'Inativo'}
                  </Badge>
                </div>
                <Separator />
                {/* Adicionar mais métricas aqui (FPS, latência, etc.) */}
                <p className="text-xs text-muted-foreground">Métricas em tempo real aparecerão aqui (placeholder).</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Dispositivos Conectados</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {devices.map((device) => (
                  <div key={device.id} className="flex justify-between items-center">
                    <div>
                      <p className="text-sm font-medium">{device.id}</p>
                      <p className="text-xs text-muted-foreground">{device.type}</p>
                    </div>
                    <Badge variant={device.status === 'connected' ? 'default' : 'destructive'}>
                      {device.status === 'connected' ? 'Conectado' : 'Desconectado'}
                    </Badge>
                  </div>
                ))}
                <Separator />
                <Button variant="outline" size="sm" className="w-full" onClick={() => toast.info('Funcionalidade de busca de dispositivos ainda não implementada.')}>
                  Buscar Novos Dispositivos
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Atores</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm mb-3">Gerencie os atores na cena (placeholder).</p>
                {/* Placeholder para lista de atores */}
                <Button variant="outline" size="sm" className="w-full" onClick={() => toast.info('Gerenciamento de atores ainda não implementado.')}>
                  Adicionar Ator
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default MoCapPage;

