# src/routes/mocap.py

from flask import Blueprint, jsonify, request

mocap_bp = Blueprint("mocap", __name__)

# --- Estado Simulado --- 
# Em uma aplicação real, isso seria gerenciado de forma mais robusta
# (ex: banco de dados, cache, gerenciador de estado)
mocap_status = {
    "is_capturing": False,
    "status": "idle", # idle, capturing, calibrating, error
    "devices": [
        { "id": "sensor-01", "type": "Body Suit", "status": "connected" },
        { "id": "sensor-02", "type": "Gloves", "status": "disconnected" },
        { "id": "camera-01", "type": "Facial Cam", "status": "connected" },
    ],
    "actors": []
}

@mocap_bp.route("/mocap/status", methods=["GET"])
def get_status():
    """Retorna o status atual da captura de movimento."""
    # Simulação: Em produção, verificaria o status real do hardware/software
    return jsonify(mocap_status)

@mocap_bp.route("/mocap/start", methods=["POST"])
def start_capture():
    """Inicia a captura de movimento."""
    # Simulação: Comando para iniciar hardware/software de captura
    if not mocap_status["is_capturing"]:
        mocap_status["is_capturing"] = True
        mocap_status["status"] = "capturing"
        print("INFO: Iniciando captura de movimento (simulado)")
        # Aqui iria a lógica para iniciar a captura real
    return jsonify({"message": "Captura iniciada (simulado)", "status": mocap_status}), 200

@mocap_bp.route("/mocap/stop", methods=["POST"])
def stop_capture():
    """Para a captura de movimento."""
    # Simulação: Comando para parar hardware/software de captura
    if mocap_status["is_capturing"]:
        mocap_status["is_capturing"] = False
        mocap_status["status"] = "idle"
        print("INFO: Parando captura de movimento (simulado)")
        # Aqui iria a lógica para parar a captura real
    return jsonify({"message": "Captura parada (simulado)", "status": mocap_status}), 200

@mocap_bp.route("/mocap/calibrate", methods=["POST"])
def calibrate():
    """Inicia o processo de calibração."""
    # Simulação: Comando para iniciar calibração
    previous_state = mocap_status["status"]
    mocap_status["status"] = "calibrating"
    print("INFO: Iniciando calibração (simulado)")
    # Simular duração da calibração
    # Em uma app real, isso seria assíncrono ou teria um endpoint de status
    # Aqui, apenas retornamos imediatamente e simulamos a mudança de estado
    # O frontend pode precisar de polling ou WebSockets para saber quando terminou
    # Exemplo simples de retorno ao estado anterior após X segundos (não ideal para API real)
    # threading.Timer(5.0, lambda: mocap_status.update({"status": previous_state})).start()
    return jsonify({"message": "Calibração iniciada (simulado)", "status": mocap_status}), 202 # Accepted

@mocap_bp.route("/mocap/devices", methods=["GET"])
def get_devices():
    """Lista os dispositivos de captura detectados."""
    # Simulação: Em produção, buscaria dispositivos conectados
    return jsonify({"devices": mocap_status["devices"]})

# --- WebSocket (Placeholder) --- 
# A implementação de WebSockets com Flask geralmente requer extensões como Flask-SocketIO
# @socketio.on("connect", namespace="/mocap")
# def handle_mocap_connect():
#     print("Cliente conectado ao namespace /mocap")

# @socketio.on("disconnect", namespace="/mocap")
# def handle_mocap_disconnect():
#     print("Cliente desconectado do namespace /mocap")

# def stream_mocap_data():
#     """Função para enviar dados MoCap via WebSocket (executada em background)."""
#     while mocap_status["is_capturing"]:
#         # Simular dados de captura
#         data = { "timestamp": time.time(), "joints": { ... } }
#         socketio.emit("mocap_data", data, namespace="/mocap")
#         socketio.sleep(0.03) # ~30 FPS

# --- Rotas de Atores (Placeholder) ---
@mocap_bp.route("/mocap/actors", methods=["GET"])
def get_actors():
    return jsonify({"actors": mocap_status["actors"]})

@mocap_bp.route("/mocap/actors", methods=["POST"])
def add_actor():
    # Simulação
    actor_data = request.json
    new_actor = { "id": f"actor-{len(mocap_status['actors']) + 1}", "name": actor_data.get("name", "Novo Ator"), "model": actor_data.get("model", "default") }
    mocap_status["actors"].append(new_actor)
    return jsonify(new_actor), 201

