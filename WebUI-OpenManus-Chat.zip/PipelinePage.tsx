import { useState } from 'react';
import BarraNavegacao from '@/components/BarraNavegacao';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Pipeline, Upload, Download, Settings, Library, Search, FileBox } from 'lucide-react';
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';

const PipelinePage = () => {
  const [selectedAnimation, setSelectedAnimation] = useState<string | null>(null);
  const [exportFormat, setExportFormat] = useState<string>('fbx');
  const [includeMetadata, setIncludeMetadata] = useState(true);
  const [targetSoftware, setTargetSoftware] = useState<string>('blender');

  const handleExport = () => {
    if (!selectedAnimation) {
      toast.warning('Selecione uma animação para exportar.');
      return;
    }
    // Simulação: Exportar animação (requer backend)
    toast.info(`Exportando animação ${selectedAnimation} como ${exportFormat.toUpperCase()}... (Simulação)`);
    // Simular download
    setTimeout(() => {
      toast.success(`Animação ${selectedAnimation}.${exportFormat} exportada com sucesso.`);
    }, 2000);
  };

  const handleAddToLibrary = () => {
    if (!selectedAnimation) {
      toast.warning('Selecione uma animação para adicionar à biblioteca.');
      return;
    }
    // Simulação: Adicionar à biblioteca (requer backend)
    toast.success(`Animação ${selectedAnimation} adicionada à biblioteca.`);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Toaster position="top-center" />
      <BarraNavegacao />
      <main className="flex-1 container py-6 flex flex-col gap-6">
        {/* Cabeçalho */}
        <div className="flex items-center gap-2 mb-6">
          <Pipeline className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-50">
            Pipeline de Produção
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Coluna Esquerda: Seleção e Exportação */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Exportar Animação</CardTitle>
                <CardDescription>Selecione uma animação e configure as opções de exportação.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <Select onValueChange={setSelectedAnimation} value={selectedAnimation || ''}>
                  <SelectTrigger>
                    <SelectValue placeholder="Selecione a animação para exportar..." />
                  </SelectTrigger>
                  <SelectContent>
                    {/* Placeholder: Carregar lista de animações do backend */}
                    <SelectItem value="anim-01">Animação Caminhada Simples</SelectItem>
                    <SelectItem value="anim-02">Animação Corrida</SelectItem>
                    <SelectItem value="anim-03">Animação Interação Objeto</SelectItem>
                    <SelectItem value="anim-generated-01">Animação Procedural Aceno</SelectItem>
                  </SelectContent>
                </Select>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="export-format">Formato</Label>
                    <Select value={exportFormat} onValueChange={setExportFormat}>
                      <SelectTrigger id="export-format">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fbx">FBX</SelectItem>
                        <SelectItem value="bvh">BVH</SelectItem>
                        <SelectItem value="alembic">Alembic (.abc)</SelectItem>
                        {/* Adicionar mais formatos conforme necessário */}
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label htmlFor="target-software">Software Alvo</Label>
                    <Select value={targetSoftware} onValueChange={setTargetSoftware}>
                      <SelectTrigger id="target-software">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="blender">Blender</SelectItem>
                        <SelectItem value="maya">Autodesk Maya</SelectItem>
                        <SelectItem value="unreal">Unreal Engine</SelectItem>
                        <SelectItem value="unity">Unity</SelectItem>
                        <SelectItem value="generic">Genérico</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox id="include-metadata" checked={includeMetadata} onCheckedChange={(checked) => setIncludeMetadata(Boolean(checked))} />
                  <Label htmlFor="include-metadata">Incluir Metadados (info do personagem, etc.)</Label>
                </div>

                {/* Placeholder para opções avançadas específicas do formato */}
                <Separator />
                <div className="flex justify-end gap-2">
                   <Button variant="outline" onClick={handleAddToLibrary} disabled={!selectedAnimation}>
                     <Library className="mr-2 h-4 w-4" /> Adicionar à Biblioteca
                   </Button>
                   <Button onClick={handleExport} disabled={!selectedAnimation}>
                     <Download className="mr-2 h-4 w-4" /> Exportar Animação
                   </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Integração e Streaming</CardTitle>
                <CardDescription>Configure a integração com outros softwares e streaming em tempo real.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-muted-foreground">Configurações de streaming para Unreal/Unity/etc. aparecerão aqui.</p>
                <Button variant="outline" onClick={() => toast.info('Configuração de Streaming ainda não implementada.')}>
                  <Settings className="mr-2 h-4 w-4" /> Configurar Streaming
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Coluna Direita: Biblioteca de Movimentos */}
          <div className="lg:col-span-1">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Library className="h-5 w-5" /> Biblioteca de Movimentos
                </CardTitle>
                <Input placeholder="Buscar na biblioteca..." className="mt-2" />
              </CardHeader>
              <ScrollArea className="flex-1">
                <CardContent className="space-y-3 p-4">
                  {/* Placeholder: Carregar lista da biblioteca do backend */}
                  <div className="p-3 border rounded-lg hover:bg-muted">
                    <p className="font-medium text-sm truncate">Caminhada Padrão</p>
                    <p className="text-xs text-muted-foreground">Humanoide • 5s</p>
                  </div>
                  <div className="p-3 border rounded-lg hover:bg-muted">
                    <p className="font-medium text-sm truncate">Aceno Simples</p>
                    <p className="text-xs text-muted-foreground">Humanoide • 2s</p>
                  </div>
                   <div className="p-3 border rounded-lg hover:bg-muted">
                    <p className="font-medium text-sm truncate">Salto Obstáculo</p>
                    <p className="text-xs text-muted-foreground">Humanoide • 3.5s</p>
                  </div>
                  <p className="text-muted-foreground text-sm text-center py-4">...</p>
                </CardContent>
              </ScrollArea>
              <CardContent className="border-t p-4">
                 <Button variant="outline" className="w-full" onClick={() => toast.info('Gerenciamento da biblioteca ainda não implementado.')}>
                   Gerenciar Biblioteca
                 </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default PipelinePage;

