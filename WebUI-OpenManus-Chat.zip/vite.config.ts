import { defineConfig } from "vite";
import react from "@vitejs/plugin-react-swc";
import path from "path";
import { componentTagger } from "lovable-tagger";

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => ({
  server: {
    host: "::", // Listen on all network interfaces
    port: 5173, // Use port 5173 as specified in the dev command
    // Add the allowed host for the temporary public domain
    allowedHosts: [
        "5173-ixhkbp4z3vi5iuiczg7lc-0b517b43.manus.computer"
    ],
    // Optional: Configure proxy if needed to talk to backend on port 5001
    // proxy: {
    //   '/api': {
    //     target: 'http://localhost:5001',
    //     changeOrigin: true,
    //     rewrite: (path) => path.replace(/^\/api/, ''),
    //   },
    // }
  },
  plugins: [
    react(),
    mode === 'development' &&
    componentTagger(),
  ].filter(Boolean),
  resolve: {
    alias: {
      "@": path.resolve(__dirname, "./src"),
    },
  },
}));

