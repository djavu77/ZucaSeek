import { useState } from 'react';
import BarraNavegacao from '@/components/BarraNavegacao';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { User, Upload, Settings2, Smile, Users, Search, EyeOff } from 'lucide-react'; // Adicionado EyeOff
import { Separator } from '@/components/ui/separator';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';
import { Badge } from '@/components/ui/badge';

const CharactersPage = () => {
  const [selectedCharacter, setSelectedCharacter] = useState<any>(null); // Placeholder para personagem selecionado
  const [characters, setCharacters] = useState([
    { id: 'char-01', name: 'Personagem Padrão', type: 'Humanoide', rigged: true, lastModified: '2024-05-04' },
    { id: 'char-02', name: 'Robô Simples', type: 'Mecânico', rigged: false, lastModified: '2024-05-03' },
    { id: 'char-03', name: 'Criatura Fantasia', type: 'Não-Humanoide', rigged: true, lastModified: '2024-05-01' },
  ]);

  const handleUploadCharacter = () => {
    // Simulação: Upload de personagem (requer backend)
    toast.info('Funcionalidade de upload de personagem ainda não implementada.');
  };

  const handleAutoRig = (charId: string) => {
    // Simulação: Rigging automático (requer backend)
    toast.info(`Iniciando rigging automático para ${charId}... (Simulação)`);
    // Atualizar estado local (simulação)
    setTimeout(() => {
      setCharacters(chars => chars.map(c => c.id === charId ? { ...c, rigged: true } : c));
      toast.success(`Rigging automático para ${charId} concluído. (Simulação)`);
    }, 3000);
  };

  const handleRetarget = () => {
    // Simulação: Retargeting (requer backend)
    if (selectedCharacter) {
      toast.info(`Iniciando retargeting para ${selectedCharacter.name}... (Simulação)`);
    } else {
      toast.warning('Selecione um personagem primeiro.');
    }
  };

  const handleFacialExpressions = () => {
    // Simulação: Configuração de expressões faciais (requer backend)
    if (selectedCharacter) {
      toast.info(`Abrindo editor de expressões faciais para ${selectedCharacter.name}... (Simulação)`);
    } else {
      toast.warning('Selecione um personagem primeiro.');
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Toaster position="top-center" />
      <BarraNavegacao />
      <main className="flex-1 container py-6 flex flex-col gap-6">
        {/* Cabeçalho */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users className="h-8 w-8 text-primary" /> {/* Ícone mais apropriado */}
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-50">
              Gerenciador de Personagens
            </h1>
          </div>
          <Button onClick={handleUploadCharacter}>
            <Upload className="mr-2 h-4 w-4" /> Carregar Personagem
          </Button>
        </div>

        {/* Layout Principal: Lista, Visualização 3D e Controles */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1">
          {/* Coluna Esquerda: Lista de Personagens */}
          <div className="lg:col-span-1">
            <Card className="h-full flex flex-col">
              <CardHeader>
                <CardTitle>Biblioteca de Personagens</CardTitle>
                <Input placeholder="Buscar personagens..." className="mt-2" />
              </CardHeader>
              <ScrollArea className="flex-1">
                <CardContent className="space-y-3 p-4">
                  {characters.map((char) => (
                    <div
                      key={char.id}
                      className={`p-3 border rounded-lg cursor-pointer hover:bg-muted ${selectedCharacter?.id === char.id ? 'bg-muted border-primary' : ''}`}
                      onClick={() => setSelectedCharacter(char)}
                    >
                      <div className="flex justify-between items-center mb-1">
                        <p className="font-medium text-sm truncate">{char.name}</p>
                        <Badge variant={char.rigged ? 'default' : 'secondary'}>
                          {char.rigged ? 'Rigged' : 'Não Rigged'}
                        </Badge>
                      </div>
                      <p className="text-xs text-muted-foreground">{char.type} • Modificado: {char.lastModified}</p>
                      {!char.rigged && (
                        <Button
                          variant="outline"
                          size="xs"
                          className="mt-2 w-full"
                          onClick={(e) => { e.stopPropagation(); handleAutoRig(char.id); }}
                        >
                          Auto-Rig
                        </Button>
                      )}
                    </div>
                  ))}
                  {characters.length === 0 && (
                     <p className="text-muted-foreground text-sm text-center py-4">Nenhum personagem carregado.</p>
                  )}
                </CardContent>
              </ScrollArea>
            </Card>
          </div>

          {/* Coluna Direita: Visualização 3D e Controles */}
          <div className="lg:col-span-2 flex flex-col gap-6">
            <Card className="flex-1 flex flex-col">
              <CardHeader>
                <CardTitle>Visualização 3D</CardTitle>
                <CardDescription>{selectedCharacter ? `Visualizando: ${selectedCharacter.name}` : 'Selecione um personagem da lista'}</CardDescription>
              </CardHeader>
              {/* Placeholder Explícito */}
              <CardContent className="flex-1 flex items-center justify-center bg-gray-100 dark:bg-gray-800 rounded-b-lg border-dashed border-2 border-gray-300 dark:border-gray-700">
                {selectedCharacter ? (
                  <div className="text-center text-muted-foreground p-4">
                    <EyeOff className="mx-auto h-12 w-12 mb-3 text-gray-400 dark:text-gray-600" />
                    <p className="font-semibold">Espaço Reservado para Visualização 3D</p>
                    <p className="text-sm">A renderização real do personagem "{selectedCharacter.name}" não está implementada nesta versão simulada.</p>
                  </div>
                ) : (
                  <div className="text-center text-muted-foreground p-4">
                     <EyeOff className="mx-auto h-12 w-12 mb-3 text-gray-400 dark:text-gray-600" />
                     <p className="font-semibold">Selecione um personagem</p>
                     <p className="text-sm">Selecione um personagem da lista à esquerda para visualizar aqui (placeholder).</p>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Controles do Personagem</CardTitle>
              </CardHeader>
              <CardContent className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <Button variant="outline" onClick={() => toast.info('Edição de Rig Manual ainda não implementada.')} disabled={!selectedCharacter}>
                  <Settings2 className="mr-2 h-4 w-4" /> Editar Rig
                </Button>
                <Button variant="outline" onClick={handleRetarget} disabled={!selectedCharacter}>
                  <Users className="mr-2 h-4 w-4" /> Retargeting
                </Button>
                <Button variant="outline" onClick={handleFacialExpressions} disabled={!selectedCharacter}>
                  <Smile className="mr-2 h-4 w-4" /> Expressões Faciais
                </Button>
                <Button variant="outline" onClick={() => toast.info('Configuração de Física ainda não implementada.')} disabled={!selectedCharacter}>
                  {/* Ícone de Física? */} Física
                </Button>
                <Button variant="outline" onClick={() => toast.info('Edição de Materiais ainda não implementada.')} disabled={!selectedCharacter}>
                  {/* Ícone de Materiais? */} Materiais
                </Button>
                <Button variant="destructive" onClick={() => toast.warning('Funcionalidade de excluir personagem ainda não implementada.')} disabled={!selectedCharacter}>
                  Excluir Personagem
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
};

export default CharactersPage;

