
import { Suspense, lazy } from 'react';
import { Routes, Route } from 'react-router-dom';
import { Toaster } from "@/components/ui/toaster";
import TelaCarregamento from '@/components/TelaCarregamento';

// Lazy load components
const Index = lazy(() => import('@/pages/Index'));
// const InstaladorGptNeo = lazy(() => import('@/pages/InstaladorGptNeo')); // Comentado, pois parece específico e pode ser integrado ao dashboard/config
const ConfiguracaoPage = lazy(() => import('@/pages/ConfiguracaoPage'));
const ManusChatPage = lazy(() => import('@/pages/ManusChat'));
const ManusDashboard = lazy(() => import('@/pages/ManusDashboard'));
const NotFound = lazy(() => import('@/pages/NotFound'));

// Novas páginas do Manus AI (placeholders iniciais)
const MoCapPage = lazy(() => import('@/pages/MoCapPage'));
const AnimationEditorPage = lazy(() => import('@/pages/AnimationEditorPage'));
const CharactersPage = lazy(() => import('@/pages/CharactersPage'));
const AIToolsPage = lazy(() => import('@/pages/AIToolsPage'));
const PipelinePage = lazy(() => import('@/pages/PipelinePage'));

function App() {
  return (
    <>
      <Suspense fallback={<TelaCarregamento />}>
        <Routes>
          {/* Rotas existentes */}
          <Route path="/" element={<ManusDashboard />} /> {/* Mudar Index para Dashboard como página inicial */}
          <Route path="/dashboard" element={<ManusDashboard />} />
          {/* <Route path="/instalador-gptneo" element={<InstaladorGptNeo />} /> */}
          <Route path="/config" element={<ConfiguracaoPage />} /> {/* Renomear rota para /config */}
          <Route path="/chat" element={<ManusChatPage />} />
          
          {/* Novas rotas Manus AI */}
          <Route path="/mocap" element={<MoCapPage />} />
          <Route path="/animation" element={<AnimationEditorPage />} />
          <Route path="/characters" element={<CharactersPage />} />
          <Route path="/ai-tools" element={<AIToolsPage />} />
          <Route path="/pipeline" element={<PipelinePage />} />
          
          {/* Rota não encontrada */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </Suspense>
      <Toaster />
    </>
  );
}

export default App;

