
export interface ManusConfig {
  isInstalled: boolean;
  apiKey?: string;
  endpoint?: string;
  modelVersion: string;
  language: string;
  advancedOptions?: {
    contextLength: number;
    temperature: number;
    topP: number;
    maxTokens: number;
    systemPrompt?: string;
    logging: boolean;
    autoConnect: boolean;
  };
  lastConnected?: Date;
  installDetails?: {
    installDate: Date;
    version: string;
    dockerImage: string;
  }
}

export const defaultManusConfig: ManusConfig = {
  isInstalled: false,
  modelVersion: 'manus-1.0',
  language: 'pt-BR',
  advancedOptions: {
    contextLength: 4096,
    temperature: 0.7,
    topP: 0.9,
    maxTokens: 2048,
    systemPrompt: 'Você é o assistente Manus AI, projetado para ajudar em tarefas de desenvolvimento.',
    logging: false,
    autoConnect: true
  }
};

export const loadManusConfig = (): ManusConfig => {
  const savedConfig = localStorage.getItem('manus_config');
  if (savedConfig) {
    try {
      return JSON.parse(savedConfig);
    } catch (error) {
      console.error('Erro ao carregar configuração da Manus:', error);
      return defaultManusConfig;
    }
  }
  return defaultManusConfig;
};

export const saveManusConfig = (config: ManusConfig): void => {
  try {
    localStorage.setItem('manus_config', JSON.stringify(config));
  } catch (error) {
    console.error('Erro ao salvar configuração da Manus:', error);
  }
};

export const updateManusInstallation = (isInstalled: boolean, endpoint?: string): void => {
  const config = loadManusConfig();
  const updatedConfig: ManusConfig = {
    ...config,
    isInstalled,
    endpoint: endpoint || config.endpoint,
  };
  
  if (isInstalled) {
    updatedConfig.installDetails = {
      installDate: new Date(),
      version: config.modelVersion,
      dockerImage: 'openmanus/core:latest'
    };
    updatedConfig.lastConnected = new Date();
  }
  
  saveManusConfig(updatedConfig);
};

export const testManusConnection = async (): Promise<boolean> => {
  const config = loadManusConfig();
  
  if (!config.isInstalled || !config.endpoint) {
    return false;
  }
  
  // Em um ambiente real, aqui faria uma chamada à API para verificar a conexão
  // Por enquanto, vamos simular uma verificação
  try {
    // Simular verificação de conexão
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Simulação de sucesso (70% de chance)
    const isConnected = Math.random() > 0.3;
    
    if (isConnected) {
      // Atualizar data de última conexão
      const updatedConfig = {
        ...config,
        lastConnected: new Date()
      };
      saveManusConfig(updatedConfig);
    }
    
    return isConnected;
  } catch (error) {
    console.error('Erro ao testar conexão com Manus:', error);
    return false;
  }
};
