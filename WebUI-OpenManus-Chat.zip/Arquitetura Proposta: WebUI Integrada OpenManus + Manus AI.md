# Arquitetura Proposta: WebUI Integrada OpenManus + Manus AI

## 1. Visão Geral

Esta arquitetura visa integrar as funcionalidades de gerenciamento de IA e chat do projeto "OpenManus" (baseado na aplicação React fornecida) com as capacidades avançadas de captura de movimento, animação e pipeline de produção descritas na especificação "Manus AI".

A solução consistirá em:

*   **Frontend:** Uma aplicação web React/TypeScript (baseada no código fornecido) que servirá como a interface principal do usuário.
*   **Backend:** Um conjunto de serviços backend (a serem desenvolvidos, provavelmente em Python/Flask) para lidar com a lógica complexa de captura de movimento, processamento de animação, IA e integração de pipeline.
*   **API:** Uma API RESTful (e potencialmente WebSockets para dados em tempo real) para comunicação entre o frontend e o backend.

## 2. Componentes

### 2.1. Frontend (React/TypeScript)

*   **Base:** Utilizar a estrutura existente do projeto `agente-inteligente-vers-main` (Vite, React, TypeScript, shadcn-ui, Tailwind CSS).
*   **Módulos Existentes (Adaptados):**
    *   `ManusDashboard`: Expandir para incluir status e controles básicos dos novos serviços de backend (MoCap, Animação).
    *   `ManusChat`: Manter para interação com modelos de linguagem. Potencialmente estender para controlar funcionalidades de animação via comandos de texto (requisito avançado).
    *   `ConfiguracaoPage`: Adicionar configurações para os novos módulos (dispositivos MoCap, parâmetros de animação, configurações de exportação).
    *   `BarraNavegacao`: Adicionar links para as novas seções/páginas.
*   **Novos Módulos/Páginas:**
    *   `MoCapInterface`: Visualização em tempo real (simulada ou real via WebSocket), controle de dispositivos, calibração, gerenciamento de atores.
    *   `AnimationEditor`: Linha do tempo visual, ferramentas de edição de keyframes, blending, visualização 3D do personagem animado (usando bibliotecas como Three.js ou Babylon.js).
    *   `CharacterManager`: Interface para upload/seleção de modelos 3D, gerenciamento de rigging (automático/manual), retargeting, configuração de expressões faciais.
    *   `AIAnimationControls`: Interface para acionar tarefas de IA (geração secundária, preenchimento de gaps, geração procedural), ajuste de parâmetros.
    *   `PipelineManager`: Opções de exportação (FBX, BVH), gerenciamento de biblioteca de movimentos, configurações de integração (simuladas).

### 2.2. Backend (Proposta: Python/Flask)

*   **Tecnologia:** Python 3.11 com Flask. Pode necessitar de bibliotecas C++ para performance (via bindings Python), mas isso adiciona complexidade. Bibliotecas Python para 3D (ex: `trimesh`, `pyrender`), processamento de dados (NumPy, SciPy) e IA (TensorFlow/PyTorch) serão necessárias.
*   **Serviços/Módulos:**
    *   **Serviço OpenManus Core (Existente/Simulado):** Lida com a interação do modelo de linguagem (chat, gerenciamento de modelos locais/remotos).
    *   **Serviço MoCap:**
        *   Interface com hardware de captura (simulado inicialmente).
        *   Processamento de dados brutos dos sensores.
        *   Calibração.
        *   Streaming de dados em tempo real (via WebSocket).
        *   Endpoints: `/api/mocap/start`, `/api/mocap/stop`, `/api/mocap/calibrate`, `/api/mocap/devices`, `/ws/mocap/stream`.
    *   **Serviço de Animação:**
        *   Carregar/Salvar dados de animação.
        *   Implementar lógica de edição (keyframes, blending, limpeza).
        *   Aplicar físicas básicas.
        *   Endpoints: `/api/animation/load`, `/api/animation/save`, `/api/animation/edit`, `/api/animation/blend`.
    *   **Serviço de Personagem:**
        *   Gerenciar modelos 3D.
        *   Implementar rigging e retargeting.
        *   Gerenciar expressões faciais e deformações.
        *   Endpoints: `/api/character/upload`, `/api/character/rig`, `/api/character/retarget`, `/api/character/models`.
    *   **Serviço de IA para Animação:**
        *   Integrar modelos de ML para tarefas de animação.
        *   Endpoints: `/api/ai/generate_secondary`, `/api/ai/fill_gaps`, `/api/ai/procedural`.
    *   **Serviço de Pipeline:**
        *   Exportar animações para formatos padrão (FBX, BVH).
        *   Gerenciar biblioteca de movimentos.
        *   Endpoints: `/api/pipeline/export`, `/api/pipeline/library`.

## 3. Comunicação (API)

*   **REST API:** Para a maioria das operações (configuração, iniciar/parar tarefas, carregar/salvar dados).
*   **WebSockets:** Para streaming de dados em tempo real (ex: dados MoCap para visualização no frontend).

## 4. Considerações

*   **Complexidade:** A implementação completa das funcionalidades do Manus AI é um projeto extenso e complexo, especialmente as partes de processamento 3D em tempo real, física, rigging complexo e IA avançada.
*   **Hardware:** A captura de movimento real requer hardware específico (sensores inerciais, câmeras) que não está disponível no ambiente sandbox. A implementação inicial dependerá de simulações.
*   **Backend:** O desenvolvimento do backend é crucial e representa a maior parte do esforço. A especificação original sugere C++, o que pode ser necessário para performance, mas Python/Flask é mais viável no ambiente atual.
*   **Visualização 3D:** O frontend precisará de uma biblioteca robusta de renderização 3D (ex: Three.js) para visualizar personagens e animações.

## 5. Próximos Passos (Implementação)

1.  **Estrutura Backend:** Criar a estrutura básica do projeto Flask com os diferentes serviços/blueprints.
2.  **Frontend Base:** Adaptar a navegação e o dashboard do React para incluir as novas seções.
3.  **Implementação Incremental:** Desenvolver e integrar cada módulo (MoCap, Animação, etc.) de forma incremental, começando com funcionalidades básicas e simulações.
