
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom'; // Importar Link e useLocation
import { Moon, Sun, Menu, X, Brain, Settings, Bot, User, Bell, Film, PersonStanding, Sparkles, Pipeline, LayoutDashboard } from 'lucide-react'; // Adicionar novos ícones
import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/components/ui/use-toast";
import { cn } from "@/lib/utils"; // Importar cn para classes condicionais

const BarraNavegacao = () => {
  const [tema, setTema] = useState<'light' | 'dark'>('light');
  const { toast } = useToast();
  const location = useLocation(); // Obter a localização atual

  const alternarTema = () => {
    const novoTema = tema === 'light' ? 'dark' : 'light';
    setTema(novoTema);
    document.documentElement.classList.toggle('dark', novoTema === 'dark');
    
    toast({
      title: `Tema ${novoTema === 'light' ? 'claro' : 'escuro'} ativado`,
      description: "A interface foi atualizada com o novo tema."
    });
  };

  // Definir itens de navegação
  const navItems = [
    { href: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
    { href: "/chat", label: "Chat IA", icon: Bot },
    { href: "/mocap", label: "Captura Mov.", icon: PersonStanding },
    { href: "/animation", label: "Editor Animação", icon: Film },
    { href: "/characters", label: "Personagens", icon: User }, // Usando User como placeholder
    { href: "/ai-tools", label: "Ferramentas IA", icon: Sparkles },
    { href: "/pipeline", label: "Pipeline", icon: Pipeline },
    { href: "/config", label: "Configurações", icon: Settings },
  ];

  return (
    <header className="border-b sticky top-0 z-10 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center gap-2">
          {/* Botão do Menu Mobile */}
          <Sheet>
            <SheetTrigger asChild className="md:hidden">
              <Button variant="ghost" size="icon">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="flex flex-col gap-6 py-6">
                <Link to="/" className="flex items-center gap-2">
                  <Brain className="h-6 w-6 text-primary" />
                  <h1 className="font-bold text-lg">OpenManus</h1>
                </Link>
                
                <nav className="flex flex-col gap-1">
                  {navItems.map((item) => (
                    <Button
                      key={item.href}
                      variant={location.pathname === item.href ? "secondary" : "ghost"}
                      className="justify-start w-full"
                      asChild // Permitir que o Button renderize como Link
                    >
                      <Link to={item.href}>
                        <item.icon className="mr-2 h-5 w-5" />
                        {item.label}
                      </Link>
                    </Button>
                  ))}
                </nav>
              </div>
            </SheetContent>
          </Sheet>
          
          {/* Logo Desktop */}
          <Link to="/" className="flex items-center gap-2">
            <Brain className="h-6 w-6 text-primary hidden sm:block" />
            <h1 className="font-bold text-lg md:text-xl">
              OpenManus
            </h1>
          </Link>
        </div>
        
        {/* Navegação Desktop */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {navItems.map((item) => (
            <Button
              key={item.href}
              variant={location.pathname === item.href ? "secondary" : "ghost"}
              size="sm"
              className="gap-1"
              asChild
            >
               <Link to={item.href}>
                 <item.icon className="mr-1 h-4 w-4" />
                 {item.label}
               </Link>
            </Button>
          ))}
        </nav>
        
        {/* Controles Direita */}
        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="relative" onClick={() => toast({ title: "Notificações", description: "Você não tem novas notificações." })}>
            <Bell className="h-5 w-5" />
            {/* Badge de Notificação (Exemplo) */}
            {/* <Badge className="h-4 w-4 p-0 absolute -top-0.5 -right-0.5 flex items-center justify-center text-[10px]">3</Badge> */}
          </Button>
          
          <Button variant="ghost" size="icon" onClick={alternarTema}>
            {tema === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
            <span className="sr-only">Alternar tema</span>
          </Button>
          
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="rounded-full">
                <User className="h-5 w-5" />
                <span className="sr-only">Perfil</span>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem>Meu perfil</DropdownMenuItem>
              <DropdownMenuItem asChild><Link to="/config">Configurações</Link></DropdownMenuItem> 
              <DropdownMenuItem>Ajuda e suporte</DropdownMenuItem>
              <DropdownMenuItem>Sair</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </header>
  );
};

export default BarraNavegacao;

