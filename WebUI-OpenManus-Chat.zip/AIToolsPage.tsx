import { useState } from 'react';
import BarraNavegacao from '@/components/BarraNavegacao';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Sparkles, Wand2, Puzzle, FileText, Settings, EyeOff } from 'lucide-react'; // Adicionado EyeOff
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { Toaster } from '@/components/ui/sonner';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const AIToolsPage = () => {
  const [secondaryMotionIntensity, setSecondaryMotionIntensity] = useState([50]);
  const [gapFillSensitivity, setGapFillSensitivity] = useState([75]);
  const [proceduralCommand, setProceduralCommand] = useState('');
  const [selectedAnimation, setSelectedAnimation] = useState<string | null>(null); // ID da animação a ser processada

  const handleApplySecondaryMotion = () => {
    if (!selectedAnimation) {
      toast.warning('Selecione uma animação para aplicar o efeito.');
      return;
    }
    // Simulação: Aplicar movimento secundário (requer backend)
    toast.info(`Aplicando movimento secundário à animação ${selectedAnimation} com intensidade ${secondaryMotionIntensity[0]}... (Simulação - sem visualização)`);
  };

  const handleApplyGapFilling = () => {
    if (!selectedAnimation) {
      toast.warning('Selecione uma animação para preencher gaps.');
      return;
    }
    // Simulação: Preencher gaps (requer backend)
    toast.info(`Preenchendo gaps na animação ${selectedAnimation} com sensibilidade ${gapFillSensitivity[0]}... (Simulação - sem visualização)`);
  };

  const handleGenerateProcedural = () => {
    if (!proceduralCommand) {
      toast.warning('Digite um comando para a geração procedural.');
      return;
    }
    // Simulação: Geração procedural (requer backend)
    toast.info(`Gerando animação procedural com o comando: "${proceduralCommand}"... (Simulação - sem visualização)`);
    // Idealmente, isso adicionaria uma nova animação à lista ou atualizaria a visualização
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <Toaster position="top-center" />
      <BarraNavegacao />
      <main className="flex-1 container py-6 flex flex-col gap-6">
        {/* Cabeçalho */}
        <div className="flex items-center gap-2 mb-6">
          <Sparkles className="h-8 w-8 text-primary" />
          <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-50">
            Ferramentas de IA para Animação
          </h1>
        </div>

        {/* Seleção de Animação Alvo */}
        <Card>
          <CardHeader>
            <CardTitle>Animação Alvo</CardTitle>
            <CardDescription>Selecione a animação na qual deseja aplicar as ferramentas de IA (simuladas).</CardDescription>
          </CardHeader>
          <CardContent>
            <Select onValueChange={setSelectedAnimation} value={selectedAnimation || ''}>
              <SelectTrigger className="w-full md:w-1/2">
                <SelectValue placeholder="Selecione uma animação (exemplo)..." />
              </SelectTrigger>
              <SelectContent>
                {/* Placeholder: Carregar lista de animações do backend */}
                <SelectItem value="anim-01">Animação Caminhada Simples</SelectItem>
                <SelectItem value="anim-02">Animação Corrida</SelectItem>
                <SelectItem value="anim-03">Animação Interação Objeto</SelectItem>
              </SelectContent>
            </Select>
            {!selectedAnimation && <p className="text-sm text-muted-foreground mt-2">Nenhuma animação selecionada.</p>}
            {selectedAnimation && <p className="text-sm text-green-600 dark:text-green-400 mt-2">Animação "{selectedAnimation}" selecionada para processamento simulado.</p>}
          </CardContent>
        </Card>

        {/* Grid de Ferramentas IA */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {/* Geração de Movimentos Secundários */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wand2 className="h-5 w-5" /> Movimentos Secundários
              </CardTitle>
              <CardDescription>Gere automaticamente movimentos sutis (roupas, cabelo, etc.) baseados na animação principal.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="secondary-intensity">Intensidade: {secondaryMotionIntensity[0]}</Label>
                <Slider
                  id="secondary-intensity"
                  defaultValue={secondaryMotionIntensity}
                  max={100}
                  step={1}
                  onValueChange={setSecondaryMotionIntensity}
                  disabled={!selectedAnimation}
                />
              </div>
              <Button className="w-full" onClick={handleApplySecondaryMotion} disabled={!selectedAnimation}>
                Aplicar Movimento Secundário (Simulado)
              </Button>
            </CardContent>
          </Card>

          {/* Preenchimento de Gaps */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Puzzle className="h-5 w-5" /> Preenchimento de Gaps
              </CardTitle>
              <CardDescription>Preencha automaticamente trechos faltantes ou com falhas na animação.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="gap-sensitivity">Sensibilidade: {gapFillSensitivity[0]}</Label>
                <Slider
                  id="gap-sensitivity"
                  defaultValue={gapFillSensitivity}
                  max={100}
                  step={1}
                  onValueChange={setGapFillSensitivity}
                  disabled={!selectedAnimation}
                />
              </div>
              <Button className="w-full" onClick={handleApplyGapFilling} disabled={!selectedAnimation}>
                Preencher Gaps (Simulado)
              </Button>
            </CardContent>
          </Card>

          {/* Geração Procedural por Texto */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileText className="h-5 w-5" /> Geração Procedural
              </CardTitle>
              <CardDescription>Gere animações básicas a partir de comandos de texto (ex: "andar para frente", "acenar").</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea
                placeholder="Digite o comando (ex: 'Personagem acena feliz')"
                value={proceduralCommand}
                onChange={(e) => setProceduralCommand(e.target.value)}
                rows={3}
              />
              <Button className="w-full" onClick={handleGenerateProcedural}>
                Gerar Animação (Simulado)
              </Button>
            </CardContent>
          </Card>

          {/* Placeholder Explícito para Visualização de Resultados (Opcional) */}
          <Card className="md:col-span-2 lg:col-span-3 border-dashed border-2 border-gray-300 dark:border-gray-700">
             <CardContent className="flex items-center justify-center h-full p-6">
                 <div className="text-center text-muted-foreground">
                     <EyeOff className="mx-auto h-10 w-10 mb-2 text-gray-400 dark:text-gray-600" />
                     <p className="font-semibold">Área de Visualização de Resultados (Placeholder)</p>
                     <p className="text-sm">A visualização dos resultados das ferramentas de IA não está implementada nesta versão simulada.</p>
                 </div>
             </CardContent>
          </Card>

          {/* Outras Ferramentas (Placeholders) */}
          <Card className="opacity-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" /> Correção de Movimentos
              </CardTitle>
              <CardDescription>Corrija automaticamente movimentos não naturais ou artefatos.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">(Em desenvolvimento)</p>
            </CardContent>
          </Card>
          <Card className="opacity-50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Sparkles className="h-5 w-5" /> Aprendizado de Padrões
              </CardTitle>
              <CardDescription>Treine a IA com seus próprios estilos de movimento.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">(Em desenvolvimento)</p>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
};

export default AIToolsPage;

