
import ManusChat from '@/components/ManusChat';
import BarraNavegacao from '@/components/BarraNavegacao';
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card } from '@/components/ui/card';
import { Blocks, FileText, BarChart } from 'lucide-react';

const ManusChatPage = () => {
  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <BarraNavegacao />
      
      <main className="flex-1 container py-6">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-100">
            <span className="text-purple-600">Manus</span> AI Interface
          </h1>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-3 h-[calc(100vh-16rem)]">
            <ManusChat />
          </div>
          
          <div className="h-[calc(100vh-16rem)] overflow-auto">
            <Tabs defaultValue="stats">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="stats">Estatísticas</TabsTrigger>
                <TabsTrigger value="docs">Documentos</TabsTrigger>
                <TabsTrigger value="models">Modelos</TabsTrigger>
              </TabsList>
              <TabsContent value="stats" className="space-y-4 pt-4">
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <BarChart className="h-5 w-5 text-purple-500" />
                    <h3 className="font-medium">Status do Sistema</h3>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Uso de CPU:</span>
                      <span className="font-medium">45%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Uso de Memória:</span>
                      <span className="font-medium">2.4GB / 8GB</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Status Docker:</span>
                      <span className="text-green-500">Ativo</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Status API:</span>
                      <span className="text-green-500">Ativo</span>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <Blocks className="h-5 w-5 text-purple-500" />
                    <h3 className="font-medium">Modelo Atual</h3>
                  </div>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-500">Nome:</span>
                      <span className="font-medium">OpenManus Default</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Tamanho:</span>
                      <span className="font-medium">7B parâmetros</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Contexto:</span>
                      <span className="font-medium">4K tokens</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-500">Versão:</span>
                      <span className="font-medium">1.2.0</span>
                    </div>
                  </div>
                </Card>
                
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <h3 className="font-medium">Ações Rápidas</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <Button variant="outline" size="sm">Reiniciar Docker</Button>
                    <Button variant="outline" size="sm">Verificar Atualizações</Button>
                    <Button variant="outline" size="sm">Limpar Cache</Button>
                    <Button variant="outline" size="sm">Logs do Sistema</Button>
                  </div>
                </Card>
              </TabsContent>
              
              <TabsContent value="docs" className="pt-4">
                <Card className="p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <FileText className="h-5 w-5 text-purple-500" />
                    <h3 className="font-medium">Documentos Recentes</h3>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b pb-2">
                      <div>
                        <p className="font-medium">documentacao_api.md</p>
                        <p className="text-xs text-gray-500">Editado há 2 dias</p>
                      </div>
                      <Button variant="ghost" size="sm">Abrir</Button>
                    </div>
                    <div className="flex items-center justify-between border-b pb-2">
                      <div>
                        <p className="font-medium">dataset_financeiro.csv</p>
                        <p className="text-xs text-gray-500">Importado há 3 dias</p>
                      </div>
                      <Button variant="ghost" size="sm">Abrir</Button>
                    </div>
                    <div className="flex items-center justify-between pb-2">
                      <div>
                        <p className="font-medium">instrucoes_manus.txt</p>
                        <p className="text-xs text-gray-500">Editado há 1 semana</p>
                      </div>
                      <Button variant="ghost" size="sm">Abrir</Button>
                    </div>
                    <Button variant="outline" className="w-full" size="sm">
                      Ver Todos os Documentos
                    </Button>
                  </div>
                </Card>
              </TabsContent>
              
              <TabsContent value="models" className="pt-4">
                <Card className="p-4">
                  <div className="flex justify-between items-center mb-3">
                    <h3 className="font-medium">Modelos Disponíveis</h3>
                    <Button variant="outline" size="sm">Importar</Button>
                  </div>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between border-b pb-2">
                      <div>
                        <p className="font-medium">OpenManus Default</p>
                        <p className="text-xs text-gray-500">7B • Base</p>
                      </div>
                      <div className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded">Ativo</div>
                    </div>
                    <div className="flex items-center justify-between border-b pb-2">
                      <div>
                        <p className="font-medium">Manus Small</p>
                        <p className="text-xs text-gray-500">3B • Rápido</p>
                      </div>
                      <Button variant="ghost" size="sm">Ativar</Button>
                    </div>
                    <div className="flex items-center justify-between pb-2">
                      <div>
                        <p className="font-medium">Manus Code</p>
                        <p className="text-xs text-gray-500">7B • Especialista em código</p>
                      </div>
                      <Button variant="ghost" size="sm">Ativar</Button>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
      
      <footer className="border-t py-4 text-center text-sm text-muted-foreground">
        <div className="container">
          <p>© {new Date().getFullYear()} Manus AI - Todos os direitos reservados</p>
          <p className="text-xs mt-1 text-gray-500">
            OpenManus versão 1.2.0
          </p>
        </div>
      </footer>
    </div>
  );
};

export default ManusChatPage;
