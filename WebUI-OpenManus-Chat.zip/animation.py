# src/routes/animation.py

from flask import Blueprint, jsonify, request
import time

animation_bp = Blueprint("animation", __name__)

# --- Estado Simulado --- 
# Em uma aplicação real, isso seria gerenciado por um banco de dados
animations_db = {
    "anim-01": { "id": "anim-01", "name": "Animação Caminhada Simples", "duration": 5.0, "frames": 150, "lastModified": time.time() },
    "anim-02": { "id": "anim-02", "name": "Animação Corrida", "duration": 3.0, "frames": 90, "lastModified": time.time() - 86400 },
    "anim-03": { "id": "anim-03", "name": "Animação Interação Objeto", "duration": 7.5, "frames": 225, "lastModified": time.time() - 172800 },
}

@animation_bp.route("/animations", methods=["GET"])
def get_animations():
    """Lista todas as animações disponíveis."""
    return jsonify(list(animations_db.values()))

@animation_bp.route("/animations/<string:anim_id>", methods=["GET"])
def get_animation_details(anim_id):
    """Retorna detalhes de uma animação específica."""
    animation = animations_db.get(anim_id)
    if animation:
        # Simulação: Em produção, carregaria dados mais detalhados (keyframes, etc.)
        return jsonify(animation)
    else:
        return jsonify({"error": "Animação não encontrada"}), 404

@animation_bp.route("/animations", methods=["POST"])
def create_animation():
    """Cria uma nova animação (ou carrega/importa)."""
    data = request.json
    new_id = f"anim-{len(animations_db) + 1}"
    new_anim = {
        "id": new_id,
        "name": data.get("name", f"Nova Animação {len(animations_db) + 1}"),
        "duration": data.get("duration", 0.0),
        "frames": data.get("frames", 0),
        "lastModified": time.time()
        # Aqui iria a lógica para processar dados de animação carregados
    }
    animations_db[new_id] = new_anim
    print(f"INFO: Criada/Carregada animação {new_id} (simulado)")
    return jsonify(new_anim), 201

@animation_bp.route("/animations/<string:anim_id>", methods=["PUT"])
def save_animation(anim_id):
    """Salva/Atualiza uma animação existente."""
    if anim_id not in animations_db:
        return jsonify({"error": "Animação não encontrada"}), 404
    
    data = request.json
    animations_db[anim_id]["name"] = data.get("name", animations_db[anim_id]["name"])
    # Simulação: Atualizar outros dados da animação (keyframes, etc.)
    animations_db[anim_id]["lastModified"] = time.time()
    print(f"INFO: Salva animação {anim_id} (simulado)")
    return jsonify(animations_db[anim_id])

@animation_bp.route("/animations/<string:anim_id>/edit", methods=["POST"])
def edit_animation(anim_id):
    """Aplica uma operação de edição na animação."""
    if anim_id not in animations_db:
        return jsonify({"error": "Animação não encontrada"}), 404
        
    data = request.json
    action = data.get("action")
    params = data.get("params")
    
    # Simulação: Aplicar a ação de edição (cut, copy, paste, delete, blend, etc.)
    print(f"INFO: Aplicando ação ", action, " na animação ", anim_id, " com params: ", params, " (simulado)")
    animations_db[anim_id]["lastModified"] = time.time() # Marcar como modificado
    
    # Retornar status ou a animação modificada (depende da ação)
    return jsonify({"message": f"Ação {action} aplicada (simulado)", "animation": animations_db[anim_id]})

@animation_bp.route("/animations/<string:anim_id>", methods=["DELETE"])
def delete_animation(anim_id):
    """Exclui uma animação."""
    if anim_id in animations_db:
        del animations_db[anim_id]
        print(f"INFO: Excluída animação {anim_id} (simulado)")
        return jsonify({"message": "Animação excluída com sucesso"}), 200
    else:
        return jsonify({"error": "Animação não encontrada"}), 404

