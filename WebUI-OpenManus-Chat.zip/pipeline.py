# src/routes/pipeline.py

from flask import Blueprint, jsonify, request, send_file
import time
import os
import io
import json # Import json library
import random # For simulating keyframes

# Importar (simulado) de outros módulos se necessário
# from .animation import animations_db

pipeline_bp = Blueprint("pipeline", __name__)

# Simulação de banco de dados de animações (copiado para exemplo)
animations_db = {
    "anim-01": { "id": "anim-01", "name": "Animação Caminhada Simples", "duration": 5.0, "frames": 150, "lastModified": time.time(), "data": {"type": "walk", "keyframes": 25} },
    "anim-02": { "id": "anim-02", "name": "Animação Corrida", "duration": 3.0, "frames": 90, "lastModified": time.time() - 86400, "data": {"type": "run", "keyframes": 15} },
    "anim-03": { "id": "anim-03", "name": "Animação Interação Objeto", "duration": 7.5, "frames": 225, "lastModified": time.time() - 172800, "data": {"type": "interact", "keyframes": 40} },
    "anim-proc-4": { "id": "anim-proc-4", "name": "Procedural: Personagem acena feliz...", "duration": 3.0, "frames": 90, "lastModified": time.time(), "generated_from": "Personagem acena feliz", "data": {"type": "gesture", "keyframes": 10} }
}

# Simulação da biblioteca de movimentos
library_db = {
    "lib-walk-01": { "id": "lib-walk-01", "name": "Caminhada Padrão", "type": "Humanoide", "duration": 5.0, "source_anim_id": "anim-01" },
    "lib-wave-01": { "id": "lib-wave-01", "name": "Aceno Simples", "type": "Humanoide", "duration": 2.0, "source_anim_id": "anim-proc-4" },
}

@pipeline_bp.route("/pipeline/export", methods=["POST"])
def export_animation():
    """Exporta uma animação para um formato específico (simulado como JSON)."""
    data = request.json
    anim_id = data.get("animation_id")
    export_format = data.get("format", "fbx") # Keep format for filename, but output JSON
    include_metadata = data.get("include_metadata", True)
    target_software = data.get("target_software", "generic")
    
    if not anim_id or anim_id not in animations_db:
        return jsonify({"error": "Animação alvo inválida ou não encontrada"}), 400
        
    animation = animations_db[anim_id]
    
    # Simulação: Gerar o arquivo exportado como JSO    anim_name = animation['name']
    print(f"INFO: Exportando animação {anim_id} ({anim_name}) como JSON (simulando {export_format.upper()}) (Target: {target_software}, Metadata: {include_metadata}) (simulado)") # Criar dicionário com dados da animação para exportar
    export_data = {
        "animation_id": animation["id"],
        "name": animation["name"],
        "duration_seconds": animation["duration"],
        "total_frames": animation["frames"],
        "simulated_format": export_format,
        # Simular alguns dados de keyframes
        "keyframes_data": [
            {
                "frame": i * (animation["frames"] // (animation["data"].get("keyframes", 10) or 1)), 
                "transform": {
                    "position": [round(random.uniform(-1, 1), 2), round(random.uniform(0, 1.5), 2), round(random.uniform(-1, 1), 2)],
                    "rotation": [round(random.uniform(-180, 180), 1), round(random.uniform(-180, 180), 1), round(random.uniform(-180, 180), 1)]
                }
            } for i in range(animation["data"].get("keyframes", 10) or 1)
        ]
    }
    
    if include_metadata:
        export_data["metadata"] = {
            "export_timestamp": time.time(),
            "export_time_readable": time.ctime(),
            "target_software": target_software,
            "source_system": "OpenManus WebUI (Simulated Export)"
        }
        
    # Converter para JSON string e depois para bytes
    json_string = json.dumps(export_data, indent=2)
    file_stream = io.BytesIO(json_string.encode("utf-8"))
    
    # Usar .json como extensão, mas manter o formato original no nome para clareza
    anim_name_safe = animation["name"].replace(" ", "_")
    filename = f"{anim_name_safe}_simulated_{export_format}.json"
    
    return send_file(
        file_stream,
        mimetype="application/json", # Mimetype correto para JSON
        as_attachment=True,
        download_name=filename
    )

@pipeline_bp.route("/pipeline/library", methods=["GET"])
def get_library_items():
    """Lista os itens na biblioteca de movimentos."""
    return jsonify(list(library_db.values()))

@pipeline_bp.route("/pipeline/library", methods=["POST"])
def add_to_library():
    """Adiciona uma animação à biblioteca de movimentos."""
    data = request.json
    anim_id = data.get("animation_id")
    library_name = data.get("name")
    
    if not anim_id or anim_id not in animations_db:
        return jsonify({"error": "Animação fonte inválida ou não encontrada"}), 400
        
    animation = animations_db[anim_id]
    new_lib_id = f"lib-{anim_id}-{len(library_db) + 1}"
    
    new_item = {
        "id": new_lib_id,
        "name": library_name or animation["name"], # Usar nome da animação se não fornecido
        "type": "Humanoide", # Simulação: Inferir do personagem associado?
        "duration": animation["duration"],
        "source_anim_id": anim_id
    }
    library_db[new_lib_id] = new_item
    print(f"INFO: Adicionada animação {anim_id} à biblioteca como {new_lib_id} (simulado)")
    return jsonify(new_item), 201

@pipeline_bp.route("/pipeline/library/<string:lib_id>", methods=["DELETE"])
def remove_from_library(lib_id):
    """Remove um item da biblioteca de movimentos."""
    if lib_id in library_db:
        del library_db[lib_id]
        print(f"INFO: Removido item {lib_id} da biblioteca (simulado)")
        return jsonify({"message": "Item removido da biblioteca"}), 200
    else:
        return jsonify({"error": "Item não encontrado na biblioteca"}), 404

# --- Streaming (Placeholder) ---
@pipeline_bp.route("/pipeline/stream/config", methods=["POST"])
def configure_streaming():
    """Configura parâmetros de streaming em tempo real."""
    # Simulação
    config_data = request.json
    print("INFO: Configurando streaming (simulado)", config_data)
    return jsonify({"message": "Configurações de streaming salvas (simulado)"})

@pipeline_bp.route("/pipeline/stream/start", methods=["POST"])
def start_streaming():
    """Inicia o streaming de dados de animação."""
    # Simulação
    print("INFO: Iniciando streaming (simulado)")
    return jsonify({"message": "Streaming iniciado (simulado)"})

@pipeline_bp.route("/pipeline/stream/stop", methods=["POST"])
def stop_streaming():
    """Para o streaming de dados de animação."""
    # Simulação
    print("INFO: Parando streaming (simulado)")
    return jsonify({"message": "Streaming parado (simulado)"})

