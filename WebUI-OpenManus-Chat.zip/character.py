# src/routes/character.py

from flask import Blueprint, jsonify, request
import time

character_bp = Blueprint("character", __name__)

# --- Estado Simulado --- 
# Em uma aplicação real, isso seria gerenciado por um banco de dados
characters_db = {
    "char-01": { "id": "char-01", "name": "Personagem Padrão", "type": "Humanoide", "rigged": True, "lastModified": time.time(), "model_file": "models/standard_human.fbx" },
    "char-02": { "id": "char-02", "name": "Robô Simples", "type": "Mecânico", "rigged": False, "lastModified": time.time() - 86400, "model_file": "models/simple_robot.glb" },
    "char-03": { "id": "char-03", "name": "Criatura Fantasia", "type": "Não-Humanoide", "rigged": True, "lastModified": time.time() - 172800, "model_file": "models/fantasy_creature.fbx" },
}

@character_bp.route("/characters", methods=["GET"])
def get_characters():
    """Lista todos os personagens disponíveis."""
    return jsonify(list(characters_db.values()))

@character_bp.route("/characters/<string:char_id>", methods=["GET"])
def get_character_details(char_id):
    """Retorna detalhes de um personagem específico."""
    character = characters_db.get(char_id)
    if character:
        # Simulação: Em produção, carregaria dados mais detalhados (rig, morph targets, etc.)
        return jsonify(character)
    else:
        return jsonify({"error": "Personagem não encontrado"}), 404

@character_bp.route("/characters", methods=["POST"])
def upload_character():
    """Carrega/Importa um novo modelo de personagem."""
    # Simulação: Processar upload de arquivo (request.files)
    # data = request.form
    # file = request.files["modelFile"]
    # filename = secure_filename(file.filename)
    # save_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    # file.save(save_path)
    
    new_id = f"char-{len(characters_db) + 1}"
    # name = data.get("name", f"Novo Personagem {len(characters_db) + 1}")
    name = f"Novo Personagem {len(characters_db) + 1}" # Simulação
    new_char = {
        "id": new_id,
        "name": name,
        "type": "Desconhecido", # Inferir do modelo ou pedir ao usuário
        "rigged": False, # Analisar modelo ou assumir não rigged
        "lastModified": time.time(),
        "model_file": f"uploads/{new_id}_model.fbx" # Simulação
    }
    characters_db[new_id] = new_char
    print(f"INFO: Carregado personagem {new_id} (simulado)")
    return jsonify(new_char), 201

@character_bp.route("/characters/<string:char_id>/rig", methods=["POST"])
def rig_character(char_id):
    """Aplica rigging (automático ou manual) a um personagem."""
    if char_id not in characters_db:
        return jsonify({"error": "Personagem não encontrado"}), 404
        
    # Simulação: Executar processo de rigging
    print(f"INFO: Aplicando rigging ao personagem {char_id} (simulado)")
    characters_db[char_id]["rigged"] = True
    characters_db[char_id]["lastModified"] = time.time()
    
    return jsonify({"message": "Rigging aplicado (simulado)", "character": characters_db[char_id]})

@character_bp.route("/characters/<string:char_id>/retarget", methods=["POST"])
def retarget_animation(char_id):
    """Aplica retargeting de uma animação para este personagem."""
    if char_id not in characters_db:
        return jsonify({"error": "Personagem não encontrado"}), 404
        
    data = request.json
    source_animation_id = data.get("source_animation_id")
    # Simulação: Executar processo de retargeting
    print(f"INFO: Aplicando retargeting da animação {source_animation_id} para o personagem {char_id} (simulado)")
    # Poderia retornar uma nova animação específica para este personagem
    return jsonify({"message": f"Retargeting da animação {source_animation_id} aplicado (simulado)"})

@character_bp.route("/characters/<string:char_id>/expressions", methods=["POST"])
def configure_expressions(char_id):
    """Configura ou edita expressões faciais."""
    if char_id not in characters_db:
        return jsonify({"error": "Personagem não encontrado"}), 404
        
    # Simulação: Salvar configurações de expressões faciais
    expression_data = request.json
    print(f"INFO: Configurando expressões faciais para o personagem {char_id} (simulado)", expression_data)
    characters_db[char_id]["lastModified"] = time.time()
    return jsonify({"message": "Expressões faciais configuradas (simulado)"})

@character_bp.route("/characters/<string:char_id>", methods=["DELETE"])
def delete_character(char_id):
    """Exclui um personagem."""
    if char_id in characters_db:
        del characters_db[char_id]
        print(f"INFO: Excluído personagem {char_id} (simulado)")
        return jsonify({"message": "Personagem excluído com sucesso"}), 200
    else:
        return jsonify({"error": "Personagem não encontrado"}), 404

