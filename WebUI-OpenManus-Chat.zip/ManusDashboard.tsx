
import { useState, useEffect } from 'react';
import BarraNavegacao from '@/components/BarraNavegacao';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Alert, AlertTitle, AlertDescription } from "@/components/ui/alert";
import { toast } from 'sonner';
import { loadManusConfig, saveManusConfig, ManusConfig } from '@/lib/manus/manusConfig';
import { Toaster } from "@/components/ui/sonner";
import { Separator } from "@/components/ui/separator";
import { Input } from "@/components/ui/input";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { useForm } from "react-hook-form";
import { settings, terminal, download, refresh, sliders, play, pause, check, x } from 'lucide-react';
import InstaladorGptNeoCard from '@/components/InstaladorGptNeoCard';
import ManusStatusPanel from '@/components/ManusStatusPanel';
import ManusTester from '@/components/ManusTester';

const ManusDashboard = () => {
  const [activeTab, setActiveTab] = useState("overview");
  const [manusConfig, setManusConfig] = useState<ManusConfig>(loadManusConfig());
  const [systemStatus, setSystemStatus] = useState<'online' | 'offline' | 'loading'>('loading');

  useEffect(() => {
    // Carregar configuração atual do Manus
    const config = loadManusConfig();
    setManusConfig(config);
    
    // Verificar status do sistema Manus
    checkManusStatus();
  }, []);

  const checkManusStatus = async () => {
    const config = loadManusConfig();
    
    if (!config.isInstalled || !config.endpoint) {
      setSystemStatus('offline');
      return;
    }
    
    try {
      // Simular verificação de conexão com endpoint
      // Em produção, isso seria uma chamada real à API
      setTimeout(() => {
        setSystemStatus(config.isInstalled ? 'online' : 'offline');
      }, 1500);
    } catch (error) {
      console.error("Erro ao verificar status do Manus:", error);
      setSystemStatus('offline');
    }
  };

  const form = useForm({
    defaultValues: {
      apiKey: manusConfig.apiKey || '',
      endpoint: manusConfig.endpoint || 'http://localhost:8501',
      modelVersion: manusConfig.modelVersion || 'manus-1.0',
      language: manusConfig.language || 'pt-BR',
      enableLogging: false,
      autostart: false
    }
  });

  const onSubmit = (data: any) => {
    const updatedConfig: ManusConfig = {
      ...manusConfig,
      apiKey: data.apiKey,
      endpoint: data.endpoint,
      modelVersion: data.modelVersion,
      language: data.language
    };
    
    saveManusConfig(updatedConfig);
    setManusConfig(updatedConfig);
    
    toast.success("Configurações do Manus salvas com sucesso");
  };

  const reiniciarServico = () => {
    toast.info("Reiniciando serviço Manus AI...");
    
    // Simulação de reinício
    setSystemStatus('loading');
    setTimeout(() => {
      setSystemStatus('online');
      toast.success("Serviço Manus AI reiniciado com sucesso");
    }, 3000);
  };

  const pararServico = () => {
    toast.info("Parando serviço Manus AI...");
    
    // Simulação de parada
    setSystemStatus('loading');
    setTimeout(() => {
      setSystemStatus('offline');
      toast.success("Serviço Manus AI parado com sucesso");
    }, 2000);
  };

  const iniciarServico = () => {
    toast.info("Iniciando serviço Manus AI...");
    
    // Simulação de inicialização
    setSystemStatus('loading');
    setTimeout(() => {
      setSystemStatus('online');
      toast.success("Serviço Manus AI iniciado com sucesso");
    }, 2000);
  };

  return (
    <div className="flex flex-col min-h-screen bg-gray-50 dark:bg-gray-900">
      <BarraNavegacao />
      <Toaster position="top-center" />
      
      <main className="flex-1 container py-6">
        <div className="flex flex-col gap-6">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-50 flex items-center gap-2">
              <settings className="h-8 w-8" />
              Painel de Controle OpenManus
            </h1>
            <p className="text-muted-foreground mt-1">
              Gerencie todos os aspectos da integração OpenManus, desde instalação até operação
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="md:col-span-2">
              <CardHeader className="pb-2">
                <CardTitle>Status do Sistema</CardTitle>
                <CardDescription>
                  Visão geral da integração OpenManus
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <div className={`w-3 h-3 rounded-full ${systemStatus === 'online' ? 'bg-green-500' : systemStatus === 'loading' ? 'bg-amber-500' : 'bg-red-500'}`}></div>
                      <span className="font-medium">OpenManus AI</span>
                    </div>
                    <Badge variant={systemStatus === 'online' ? 'default' : systemStatus === 'loading' ? 'outline' : 'destructive'}>
                      {systemStatus === 'online' ? 'Online' : systemStatus === 'loading' ? 'Atualizando...' : 'Offline'}
                    </Badge>
                  </div>
                  
                  <Separator />
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4 pt-2">
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Versão</p>
                      <p className="text-sm text-muted-foreground">{manusConfig.modelVersion}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Idioma</p>
                      <p className="text-sm text-muted-foreground">{manusConfig.language}</p>
                    </div>
                    <div className="space-y-1">
                      <p className="text-sm font-medium">Endpoint</p>
                      <p className="text-sm text-muted-foreground truncate">{manusConfig.endpoint || 'Não configurado'}</p>
                    </div>
                  </div>
                  
                  <div className="flex gap-2 pt-2">
                    {systemStatus === 'online' ? (
                      <>
                        <Button size="sm" onClick={reiniciarServico}>
                          <refresh className="h-4 w-4 mr-2" />
                          Reiniciar
                        </Button>
                        <Button size="sm" variant="destructive" onClick={pararServico}>
                          <pause className="h-4 w-4 mr-2" />
                          Parar Serviço
                        </Button>
                      </>
                    ) : (
                      <Button size="sm" onClick={iniciarServico} disabled={systemStatus === 'loading' || !manusConfig.isInstalled}>
                        <play className="h-4 w-4 mr-2" />
                        Iniciar Serviço
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle>Ações Rápidas</CardTitle>
                <CardDescription>
                  Comandos e utilitários comuns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 gap-3">
                  <Button className="justify-start" onClick={() => window.location.href = '/chat'}>
                    <terminal className="h-4 w-4 mr-2" />
                    Abrir Manus Chat
                  </Button>
                  
                  <Button variant="outline" className="justify-start" onClick={() => setActiveTab('config')}>
                    <settings className="h-4 w-4 mr-2" />
                    Configurações
                  </Button>
                  
                  {!manusConfig.isInstalled && (
                    <Button variant="outline" className="justify-start" onClick={() => setActiveTab('install')}>
                      <download className="h-4 w-4 mr-2" />
                      Instalação
                    </Button>
                  )}
                  
                  <Button variant="outline" className="justify-start" onClick={() => setActiveTab('test')}>
                    <check className="h-4 w-4 mr-2" />
                    Testar Conexão
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-4 w-full max-w-2xl mb-4">
              <TabsTrigger value="overview">Visão Geral</TabsTrigger>
              <TabsTrigger value="install">Instalação</TabsTrigger>
              <TabsTrigger value="config">Configuração</TabsTrigger>
              <TabsTrigger value="test">Testes</TabsTrigger>
            </TabsList>
            
            <TabsContent value="overview" className="space-y-4">
              {manusConfig.isInstalled ? (
                <ManusStatusPanel config={manusConfig} status={systemStatus} />
              ) : (
                <Card>
                  <CardHeader>
                    <CardTitle>Integração OpenManus</CardTitle>
                    <CardDescription>
                      O OpenManus ainda não está instalado. Instale para acessar todas as funcionalidades.
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Alert>
                      <AlertTitle>Instalação necessária</AlertTitle>
                      <AlertDescription>
                        Para utilizar todas as funcionalidades do OpenManus, é necessário realizar a instalação.
                        Acesse a guia "Instalação" para começar.
                      </AlertDescription>
                    </Alert>
                    <Button className="mt-4" onClick={() => setActiveTab('install')}>
                      <download className="h-4 w-4 mr-2" />
                      Iniciar Instalação
                    </Button>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
            
            <TabsContent value="install" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <InstaladorGptNeoCard variant="openmanus" />
                
                <Card>
                  <CardHeader>
                    <CardTitle>Requisitos do Sistema</CardTitle>
                    <CardDescription>
                      Certifique-se que seu sistema atende aos requisitos mínimos
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <check className="h-5 w-5 text-green-500" />
                          <span>Docker</span>
                        </div>
                        <Badge variant="outline">Necessário</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <check className="h-5 w-5 text-green-500" />
                          <span>RAM: 8GB+</span>
                        </div>
                        <Badge variant="outline">Recomendado</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <check className="h-5 w-5 text-green-500" />
                          <span>Espaço em disco: 10GB+</span>
                        </div>
                        <Badge variant="outline">Necessário</Badge>
                      </div>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <check className="h-5 w-5 text-green-500" />
                          <span>Python 3.8+</span>
                        </div>
                        <Badge variant="outline">Necessário</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
            
            <TabsContent value="config" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Configurações do OpenManus</CardTitle>
                  <CardDescription>
                    Ajuste os parâmetros de integração e funcionamento
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="endpoint"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Endpoint da API</FormLabel>
                          <FormControl>
                            <Input placeholder="http://localhost:8501" {...field} />
                          </FormControl>
                          <FormDescription>
                            URL do servidor OpenManus
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="apiKey"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Chave de API (opcional)</FormLabel>
                          <FormControl>
                            <Input placeholder="sk_..." type="password" {...field} />
                          </FormControl>
                          <FormDescription>
                            Chave secreta para autenticação (se necessário)
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="modelVersion"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Versão do Modelo</FormLabel>
                          <FormControl>
                            <Input placeholder="manus-1.0" {...field} />
                          </FormControl>
                          <FormDescription>
                            Versão do modelo OpenManus a ser utilizado
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="language"
                      render={({ field }) => (
                        <FormItem>
                  
(Content truncated due to size limit. Use line ranges to read in chunks)